package Item;

public class Item {
	public int x, y;
	public int size;
	public Item(int x,int y,int size) {
		this.x = x;
		this.y = y;
		this.size = size;
	}
}
