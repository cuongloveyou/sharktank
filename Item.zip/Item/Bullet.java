package Item;

public class Bullet {

}
